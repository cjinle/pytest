-- MySQL dump 10.13  Distrib 5.5.34, for Linux (x86_64)
--
-- Host: localhost    Database: scrapy
-- ------------------------------------------------------
-- Server version	5.5.34-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `content`
--

DROP TABLE IF EXISTS `content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `add_time` datetime NOT NULL,
  `post_id` varchar(255) CHARACTER SET utf8 NOT NULL,
  `url` varchar(255) CHARACTER SET utf8 NOT NULL,
  `keywords` varchar(255) CHARACTER SET utf16 NOT NULL,
  `desc` varchar(500) CHARACTER SET utf8 NOT NULL,
  `content` text CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content`
--

LOCK TABLES `content` WRITE;
/*!40000 ALTER TABLE `content` DISABLE KEYS */;
/*!40000 ALTER TABLE `content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `url`
--

DROP TABLE IF EXISTS `url`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `url` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` varchar(255) CHARACTER SET utf8 NOT NULL,
  `url` varchar(255) CHARACTER SET utf8 NOT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `post_id` (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=145 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `url`
--

LOCK TABLES `url` WRITE;
/*!40000 ALTER TABLE `url` DISABLE KEYS */;
INSERT INTO `url` VALUES (97,'54282','/VOA_Special_English/students-help-imagine-interactive-smithsonian-exhibit-54282.html',0),(98,'54281','/VOA_Special_English/sharks-surfing-robots-54281.html',0),(99,'54272','/VOA_Standard_English/the-year-in-roots-music-54272.html',0),(100,'54280','/VOA_Standard_English/improving-maritime-security-in-southeast-asia-54280.html',0),(101,'54277','/VOA_Standard_English/guinea-bissau-must-keep-to-election-schedule-54277.html',0),(102,'54279','/VOA_Standard_English/more-aid-for-typhoon-victims-54279.html',0),(103,'54278','/VOA_Standard_English/zeya-at-future-of-middle-east-54278.html',0),(104,'54269','/Voa_English_Learning/south-sudan-government-and-rebels-to-hold-talks-to-end-violence-54269.html',0),(105,'54268','/VOA_Special_English/prolonged-exposure-therapy-helps-sexually-abused-adolescent-girls-54268.html',0),(106,'54265','/VOA_Special_English/egypt-struggles-peace-nigeria-boko-haram-insurgency-54265.html',0),(107,'54258','/VOA_Standard_English/car-unicef-dec-54258.html',0),(108,'54255','/VOA_Standard_English/british-researchers-develop-safer-encryption-for-credit-cards-54255.html',0),(109,'54264','/VOA_Standard_English/rose-bowl-floats-brands-causes-54264.html',0),(110,'54254','/Voa_English_Learning/israel-frees-more-palestinian-prisoners-54254.html',0),(111,'54253','/Voa_English_Learning/china-baby-stealing-obstetrician-faces-death-penalty-54253.html',0),(112,'54266','/VOA_Special_English/article-54266.html',0),(113,'47890','/VOA_Special_English/the story of the poinsettia-47890.html',0),(114,'54250','/VOA_Special_English/time-clock-calendar-54250.html',0),(115,'54249','/VOA_Special_English/new-years-eve-calendar-resolutions-chocolates-54249.html',0),(116,'54252','/VOA_Standard_English/working-to-eliminate-the-deadly-triple-threat-54252.html',0),(117,'54251','/VOA_Standard_English/welcome-mediation-begins-in-sudan-crisis-54251.html',0),(118,'54248','/VOA_Standard_English/deadline-to-remove-syrias-chemical-weapons-may-pass-54248.html',0),(119,'54244','/Voa_English_Learning/japan-markets-close-at-4-decade-high-54244.html',0),(120,'54243','/Voa_English_Learning/china-says-more-than-3-million-hectares-of-land-too-polluted-to-farm-54243.html',0),(121,'54242','/VOA_Special_English/south-korea-accuses-north-korea-of-cyber-attacks-54242.html',0),(122,'54240','/VOA_Special_English/new-years-music-54240.html',0),(123,'54241','/VOA_Special_English/pakistan-criticizes-india-s-border-moves-to-fight-polio-54241.html',0),(124,'54238','/VOA_Standard_English/washington-week-renewed-focus-on-obamacare-54238.html',0),(125,'54237','/VOA_Standard_English/true-meaning-of-citizenship-macedonia-54237.html',0),(126,'54236','/VOA_Standard_English/landmark-wto-agreement-54236.html',0),(127,'54267','/VOA_Special_English/article-54267.html',0),(128,'54229','/VOA_Special_English/auld-lang-syne-new-years-eve-robert-burns-lou-rawls-54229.html',0),(129,'54230','/VOA_Special_English/future-of-cars-los-angeles-auto-show-54230.html',0),(130,'54232','/VOA_Standard_English/elections-in-bangladesh-54232.html',0),(131,'54233','/VOA_Standard_English/execution-and-rights-abuse-in-north-korea-54233.html',0),(132,'54234','/VOA_Standard_English/syrian-air-assaults-must-stop-54234.html',0),(133,'54215','/VOA_Special_English/south-sudan-salva-kiir-riek-machar-uhura-kenyatta-hailemariam-desalegn-54215.html',0),(134,'54214','/VOA_Special_English/prohibition-temperance-music-54214.html',0),(135,'54222','/VOA_Standard_English/turkey-corruption-scandal-fallout-could-spread-across-region-54222.html',0),(136,'54221','/VOA_Standard_English/political-turmoil-threatens-turkeys-government-economy-54221.html',0),(137,'54220','/VOA_Standard_English/africa-oil-dec-54220.html',0),(138,'54218','/VOA_Standard_English/california-kids-get-taste-of-winter-at-museum-54218.html',0),(139,'54217','/Voa_English_Learning/okinawa-governor-approves-plan-to-relocate-us-marine-base-54217.html',0),(140,'54216','/Voa_English_Learning/car-bomb-rocks-beirut-former-minister-assassinated-54216.html',0),(141,'54211','/VOA_Special_English/progress-reported-in-tpp-negotiations-54211.html',0),(142,'54212','/VOA_Special_English/colonial-farm-national-park-claude-moore-54212.html',0),(143,'54213','/VOA_Special_English/afghanistan-faces-election-security-issues-in--54213.html',0),(144,'54204','/VOA_Standard_English/boosting-us-commitment-to-peace-in-the-car-54204.html',0);
/*!40000 ALTER TABLE `url` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `url_20140102`
--

DROP TABLE IF EXISTS `url_20140102`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `url_20140102` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` varchar(255) CHARACTER SET utf8 NOT NULL,
  `url` varchar(255) CHARACTER SET utf8 NOT NULL,
  `status` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `post_id` (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `url_20140102`
--

LOCK TABLES `url_20140102` WRITE;
/*!40000 ALTER TABLE `url_20140102` DISABLE KEYS */;
INSERT INTO `url_20140102` VALUES (5,'54282','/VOA_Special_English/students-help-imagine-interactive-smithsonian-exhibit-54282.html',0),(6,'54281','/VOA_Special_English/sharks-surfing-robots-54281.html',0),(7,'54272','/VOA_Standard_English/the-year-in-roots-music-54272.html',0),(8,'54280','/VOA_Standard_English/improving-maritime-security-in-southeast-asia-54280.html',0),(9,'54277','/VOA_Standard_English/guinea-bissau-must-keep-to-election-schedule-54277.html',0),(10,'54279','/VOA_Standard_English/more-aid-for-typhoon-victims-54279.html',0),(11,'54278','/VOA_Standard_English/zeya-at-future-of-middle-east-54278.html',0),(12,'54269','/Voa_English_Learning/south-sudan-government-and-rebels-to-hold-talks-to-end-violence-54269.html',0),(13,'54268','/VOA_Special_English/prolonged-exposure-therapy-helps-sexually-abused-adolescent-girls-54268.html',0),(14,'54265','/VOA_Special_English/egypt-struggles-peace-nigeria-boko-haram-insurgency-54265.html',0),(15,'54258','/VOA_Standard_English/car-unicef-dec-54258.html',0),(16,'54255','/VOA_Standard_English/british-researchers-develop-safer-encryption-for-credit-cards-54255.html',0),(17,'54264','/VOA_Standard_English/rose-bowl-floats-brands-causes-54264.html',0),(18,'54254','/Voa_English_Learning/israel-frees-more-palestinian-prisoners-54254.html',0),(19,'54253','/Voa_English_Learning/china-baby-stealing-obstetrician-faces-death-penalty-54253.html',0),(20,'54266','/VOA_Special_English/article-54266.html',0),(21,'47890','/VOA_Special_English/the story of the poinsettia-47890.html',0),(22,'54250','/VOA_Special_English/time-clock-calendar-54250.html',0),(23,'54249','/VOA_Special_English/new-years-eve-calendar-resolutions-chocolates-54249.html',0),(24,'54252','/VOA_Standard_English/working-to-eliminate-the-deadly-triple-threat-54252.html',0),(25,'54251','/VOA_Standard_English/welcome-mediation-begins-in-sudan-crisis-54251.html',0),(26,'54248','/VOA_Standard_English/deadline-to-remove-syrias-chemical-weapons-may-pass-54248.html',0),(27,'54244','/Voa_English_Learning/japan-markets-close-at-4-decade-high-54244.html',0),(28,'54243','/Voa_English_Learning/china-says-more-than-3-million-hectares-of-land-too-polluted-to-farm-54243.html',0),(29,'54242','/VOA_Special_English/south-korea-accuses-north-korea-of-cyber-attacks-54242.html',0),(30,'54240','/VOA_Special_English/new-years-music-54240.html',0),(31,'54241','/VOA_Special_English/pakistan-criticizes-india-s-border-moves-to-fight-polio-54241.html',0),(32,'54238','/VOA_Standard_English/washington-week-renewed-focus-on-obamacare-54238.html',0),(33,'54237','/VOA_Standard_English/true-meaning-of-citizenship-macedonia-54237.html',0),(34,'54236','/VOA_Standard_English/landmark-wto-agreement-54236.html',0),(35,'54267','/VOA_Special_English/article-54267.html',0),(36,'54229','/VOA_Special_English/auld-lang-syne-new-years-eve-robert-burns-lou-rawls-54229.html',0),(37,'54230','/VOA_Special_English/future-of-cars-los-angeles-auto-show-54230.html',0),(38,'54232','/VOA_Standard_English/elections-in-bangladesh-54232.html',0),(39,'54233','/VOA_Standard_English/execution-and-rights-abuse-in-north-korea-54233.html',0),(40,'54234','/VOA_Standard_English/syrian-air-assaults-must-stop-54234.html',0),(41,'54215','/VOA_Special_English/south-sudan-salva-kiir-riek-machar-uhura-kenyatta-hailemariam-desalegn-54215.html',0),(42,'54214','/VOA_Special_English/prohibition-temperance-music-54214.html',0),(43,'54222','/VOA_Standard_English/turkey-corruption-scandal-fallout-could-spread-across-region-54222.html',0),(44,'54221','/VOA_Standard_English/political-turmoil-threatens-turkeys-government-economy-54221.html',0),(45,'54220','/VOA_Standard_English/africa-oil-dec-54220.html',0),(46,'54218','/VOA_Standard_English/california-kids-get-taste-of-winter-at-museum-54218.html',0),(47,'54217','/Voa_English_Learning/okinawa-governor-approves-plan-to-relocate-us-marine-base-54217.html',0),(48,'54216','/Voa_English_Learning/car-bomb-rocks-beirut-former-minister-assassinated-54216.html',0),(49,'54211','/VOA_Special_English/progress-reported-in-tpp-negotiations-54211.html',0),(50,'54212','/VOA_Special_English/colonial-farm-national-park-claude-moore-54212.html',0),(51,'54213','/VOA_Special_English/afghanistan-faces-election-security-issues-in--54213.html',0),(52,'54204','/VOA_Standard_English/boosting-us-commitment-to-peace-in-the-car-54204.html',0);
/*!40000 ALTER TABLE `url_20140102` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-01-02 19:37:46
